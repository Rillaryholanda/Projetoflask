from flask import Flask, render_template, request, redirect, url_for
from datetime import datetime

app = Flask(__name__)

tarefas = []
id_atual = 1


@app.route('/')
def index():
    tarefas_formatadas = []
    for t in tarefas:
        data_formatada = datetime.strptime(t['data'], "%Y-%m-%d").strftime("%d/%m/%Y")
        tarefa = t.copy()
        tarefa['data_formatada'] = data_formatada
        tarefas_formatadas.append(tarefa)

    return render_template('index.html', tarefas=tarefas_formatadas)


@app.route('/novo', methods=['GET', 'POST'])
def novo():
    global id_atual

    if request.method == 'POST':
        titulo = request.form['titulo']
        descricao = request.form['descricao']
        data = request.form['data']

        if titulo == "":
            return "Erro: o título não pode estar vazio!"

        data_limite = datetime.strptime(data, "%Y-%m-%d").date()
        hoje = datetime.today().date()

        if data_limite < hoje:
            return "Erro: a data não pode ser anterior a hoje!"

        tarefas.append({
            'id': id_atual,
            'titulo': titulo,
            'descricao': descricao,
            'data': data,
            'feito': False
        })
        id_atual += 1
        return redirect(url_for('index'))

    return render_template('novo.html')


@app.route('/concluir/<int:id>')
def concluir(id):
    for t in tarefas:
        if t['id'] == id:
            t['feito'] = True
    return redirect(url_for('index'))


@app.route('/excluir/<int:id>')
def excluir(id):
    global tarefas
    tarefas = [t for t in tarefas if t['id'] != id]
    return redirect(url_for('index'))


@app.route('/editar/<int:id>', methods=['GET', 'POST'])
def editar(id):
    for t in tarefas:
        if t['id'] == id:
            if request.method == 'POST':
                t['titulo'] = request.form['titulo']
                t['descricao'] = request.form['descricao']
                t['data'] = request.form['data']
                return redirect(url_for('index'))
            return render_template('editar.html', tarefa=t)
    return "Tarefa não encontrada!"


if __name__ == '__main__':
    app.run(debug=True)
